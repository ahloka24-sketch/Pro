# بوت د. ضياء العوضي - نظام الطيبات

بوت تيليجرام يعرض المسموحات والممنوعات والقواعد العامة لنظام الطيبات،
ويرسل تذكيرات بأيام الصيام (الإثنين والخميس + الأيام البيض 13/14/15 هجريًا).

---

## 🚀 طريقة النشر المجانية على Koyeb (بدون مصاريف)

**Koyeb** بيوفّر سيرفر مجاني للأبد، البوت يفضل شغّال 24/7 بدون ما ينام.

### 1️⃣ ارفع الكود على GitHub

1. ادخل [github.com](https://github.com) وسجّل دخول (أو اعمل حساب جديد)
2. اضغط **+** فوق على اليمين → **New repository**
3. اكتب اسم المشروع (مثلًا `tayyibat-bot`)
4. خليه **Public** واضغط **Create repository**
5. في الصفحة اللي ظهرت، اضغط على لينك **uploading an existing file**
6. ارفع الملفات دي:
   - `main.py`
   - `requirements.txt`
   - `Procfile`
   - `.gitignore`
7. اضغط **Commit changes**

### 2️⃣ سجّل في Koyeb

1. ادخل [koyeb.com](https://www.koyeb.com)
2. اضغط **Sign up** → سجّل دخول بـ **GitHub**
3. هيطلب رقم موبايل للتفعيل (مجاني، مش هياخد فلوس)

### 3️⃣ أنشئ خدمة جديدة

1. من لوحة التحكم اضغط **Create Service**
2. اختار **GitHub** كمصدر
3. لو طلب صلاحيات، اضغط **Configure GitHub App** ووافق على المستودع
4. اختار المستودع `tayyibat-bot`
5. اختار الفرع **main**

### 4️⃣ اضبط الإعدادات

| الحقل | القيمة |
|---|---|
| **Service type** | Worker |
| **Builder** | Buildpack |
| **Run command** | `python main.py` |
| **Instance type** | Free (eco) |
| **Regions** | Frankfurt (الأقرب لمصر) |

### 5️⃣ أضف التوكن

- انزل لقسم **Environment variables**
- اضغط **Add variable**
- **Name:** `TELEGRAM_BOT_TOKEN`
- **Value:** التوكن بتاعك من @BotFather
- اختار النوع **Secret** (مهم للأمان)

### 6️⃣ اضغط Deploy

- استنى 2-3 دقائق
- لما تشوف الحالة **Healthy** ✅ يبقى البوت شغّال
- جرّب البوت في تيليجرام واضغط /start

---

## 🆓 بدائل مجانية تانية

### Fly.io (متقدم شوية)
- [fly.io](https://fly.io) - يديك 3 سيرفرات صغيرة مجانًا
- محتاج تثبت برنامج `flyctl` على الكمبيوتر

### Replit (مدفوع)
- لازم اشتراك Replit Core الشهري عشان يفضل شغّال 24/7

---

## 📁 محتوى المشروع

```
telegram-bot/
├── main.py              # كود البوت
├── requirements.txt     # المكتبات المطلوبة
├── Procfile             # أمر التشغيل
├── .gitignore           # ملفات مستثناة من Git
└── README.md            # هذا الملف
```

## 🔧 تجربة البوت محليًا

```bash
pip install -r requirements.txt
export TELEGRAM_BOT_TOKEN="التوكن_بتاعك"
python main.py
```

---

## 💡 ملاحظات

- بيانات المشتركين بتتسجل في `subscribers.json` ضمن مجلد البوت
- التذكيرات بتتبعت الساعة 8 مساءً بتوقيت القاهرة
- الأيام البيض = 13، 14، 15 من كل شهر هجري
- Koyeb المجاني: 1 خدمة + 512MB RAM + 2.5GB تخزين + لا ينام
